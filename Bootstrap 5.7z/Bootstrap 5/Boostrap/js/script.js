console.log("hello word");

var a = 1;
var b = 2;
var R = a+b;
console.log("Resultado :" + R);

var a = 2;
var b = 2;
var j = a*b;
console.log("Resultado :" + j);


var raiz=match.sqrt(1244)
console.log("La raiz cuadrada de 1244 es: "+raiz);


var c = 500.000;
var j = 2;
var numerosPrimos = [];

for (; j < c; j++) {

  if (primo(j)) {
    numerosPrimos.push(j);
  }
  
}

console.log(numerosPrimos);

function primo(numero) {

  for (var i = 2; i < numero; i++) {

    if (numero % i === 0) {
      return false;
    }

  }

  return numero !== 1;
}